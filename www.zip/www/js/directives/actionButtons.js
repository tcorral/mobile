(function (angular) {
    var module = angular.module('app');
    module.directive('actionButtons', function () {
        return {
            restrict: 'E',
            templateUrl: 'templates/action-buttons.html',
            controller: ['$rootScope', '$scope', 'ngDialog', function ($rootScope, $scope, ngDialog) {

                $rootScope.$on('selectedItems', function (event, data) {
                    $scope.actionButtons.right.delete.show = (data.items.length > 0);
                    $scope.actionButtons.right.settings.show = (data.items.length == 1);
                });

                $rootScope.$watch('backButton', function () {
                    $rootScope.$evalAsync(function () {
                        $scope.actionButtons = $scope.actionButtons || {};

                        $scope.actionButtons.right = $scope.actionButtons.right || {};

                        $scope.actionButtons.right.delete = {
                            show: false,
                            imgUrl: '../../img/assets/delete.png',
                            action: function () {
                                $rootScope.$broadcast('delete:selected:pages');

                            }
                        };
                        $scope.actionButtons.right.user = {
                            show: true,
                            imgUrl: '../../img/assets/user.png'
                        };
                        $scope.actionButtons.right.logout = {
                            show: true,
                            imgUrl: '../../img/assets/logout.png',
                            action: function () {
                                ngDialog.open({ template: 'templates/logout.html' });
                            }
                        };
                        $scope.actionButtons.right.next = {
                            show: false,
                            imgUrl: '../../img/assets/next.png'
                        };
                        $scope.actionButtons.right.settings = {
                            show: false,
                            imgUrl: '../../img/assets/settings.png'
                        };
                    });
                });
            }]
        }
    });
}(angular));