(function (angular) {
    var module = angular.module('app');
    module.directive('actionButtons', function () {
        return {
            restrict: 'E',
            templateUrl: 'templates/action-buttons.html',
            controller: ['$rootScope', '$scope', function ($rootScope, $scope) {

                $rootScope.$on('selectedItems', function (event, data) {
                    $scope.actionButtons.right.delete.show = (data.items.length > 0);
                    $scope.actionButtons.right.settings.show = (data.items.length == 1);
                });

                $rootScope.$watch('backButton', function () {
                    $rootScope.$evalAsync(function () {
                        console.log('changed actions');
                        $scope.actionButtons = $scope.actionButtons || {};

                        $scope.actionButtons.right = $scope.actionButtons.right || {};

                        $scope.actionButtons.right.delete = {
                            show: false,
                            imgUrl: '../../img/assets/delete.png'
                        };
                        $scope.actionButtons.right.user = {
                            show: true,
                            imgUrl: '../../img/assets/user.png'
                        };
                        $scope.actionButtons.right.logout = {
                            show: true,
                            imgUrl: '../../img/assets/logout.png'
                        };
                        $scope.actionButtons.right.next = {
                            show: false,
                            imgUrl: '../../img/assets/next.png'
                        };
                        $scope.actionButtons.right.settings = {
                            show: false,
                            imgUrl: '../../img/assets/settings.png'
                        };
                    });
                });
            }]
        }
    });
}(angular));