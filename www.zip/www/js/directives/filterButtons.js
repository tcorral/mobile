(function (angular) {
    var module = angular.module('app');
    module.directive('filterButtons', function () {
        return {
            restrict: 'E',
            templateUrl: 'templates/filter-buttons.html',
            controller: ['$rootScope', '$scope', function ($rootScope, $scope) {
                $rootScope.$watch('backButton', function (backButton) {
                    $rootScope.$evalAsync(function () {
                        $scope.actionButtons = $scope.actionButtons || {};

                        $scope.actionButtons.left = $scope.actionButtons.left || {};
                        $scope.actionButtons.left.prev = {
                            show: backButton,
                            imgUrl: '../../img/assets/prev.png',
                            action: function () {
                                console.log('History', history.length);
                                window.history.back();
                            }
                        };

                        $scope.actionButtons.left.search = {
                            search: {
                                show: true,
                                imgUrl: '../../img/assets/search.png'
                            }
                        };
                    });
                });
            }]
        }
    });
}(angular));