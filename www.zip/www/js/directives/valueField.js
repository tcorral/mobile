(function (angular) {
    angular.module('app')
        .directive('valueField', function ($compile) {

            var fieldTemplates = {
                boolean: function (key, value) {
                    var template = [];
                    template.push('<div>');
                        template.push('<label>');
                            template.push(_.startCase(key));
                        template.push('</label>');
                        template.push('<input type="checkbox" ng-model="prop.val" ');
                            template.push(value === true ? 'checked="true"' : '');
                        template.push('/>');
                    template.push('</div>');
                    return template.join('');
                },
                number: function (key, value) {
                    var template = [];
                    template.push('<div>');
                    template.push('<label>');
                    template.push(_.startCase(key));
                    template.push('</label>');
                    template.push('<input type="number" min="0" step="any" ng-model="prop.val"/>');
                    template.push('</div>');
                    return template.join('');
                },
                string: function (key, value) {
                    if(typeof specialFields[key] === 'function') {
                        return specialFields[key](_.startCase(key), value);
                    }else{
                        var template = [];
                        template.push('<div>');
                        template.push('<label>');
                        template.push(_.startCase(key));
                        template.push('</label>');
                        template.push('<input type="text" ng-model="prop.val""/>');
                        template.push('</div>');
                        return template.join('');
                    }
                },
                object: function (key, value) {
                    value = JSON.parse(value);
                    var template = [];
                        template.push('<div>');
                            var typeInput = [];
                            typeInput.push('<label>');
                            typeInput.push('Field Type');
                            typeInput.push('</label>');
                            typeInput.push('<select ng-model="prop.viewHint[0]" ng-change="changeFieldType(prop, prop.viewHint[0])" ng-options="o as o for o in fileTypes">');
                            typeInput.push('</select>');

                            var designMode = [];
                            designMode.push('<label>');
                            designMode.push('Design Mode');
                            designMode.push('</label>');
                            designMode.push('<input type="checkbox" ng-model="prop.viewHint[1]"/>');

                            var role = [];
                            role.push('<label>');
                            role.push('Role');
                            role.push('</label>');
                            role.push('<select ng-model="prop.viewHint[2]" ng-change="changeFieldType(prop, prop.viewHint[2])" ng-options="o as o for o in roles">');
                            role.push('</select>');

                        template.push(typeInput.join(''));
                        template.push(designMode.join(''));
                        template.push(role.join(''));
                        template.push('</div>');
                    return template.join('');
                }
            };

            var specialFields = {
                locale: function (key, value){
                    var template = [];
                    template.push('<div>');
                    template.push('<label>');
                    template.push(key);
                    template.push('</label>');
                    template.push('<input type="checkbox" hm-tap="toggleLocale(prop)"');
                    template.push(value === 'en' ? 'checked="true"' : '');
                    template.push('/>');
                    template.push('</div>');
                    return template.join('');
                },
                thumbnailUrl: function (key, value) {
                    var template = [];
                        template.push('<div>');
                        template.push('<label>');
                        template.push(key);
                        template.push('</label>');
                        template.push('<img ng-src="');
                        template.push('http://hackathon.backbase.dev:8080');
                        template.push(value);
                        template.push('"/>');
                        template.push('<input type="file" value="');
                        template.push(value);
                        template.push('"/>');
                        template.push('</div>');
                        return template.join('');
                }
            };
            specialFields.icon = specialFields.thumbnailUrl;

            var getTemplate = function(contentType) {
                if(typeof fieldTemplates[contentType] === 'function') {
                    return fieldTemplates[contentType];
                } else {
                    return function () { return 'pepe'; };
                }
            };

            var linker = function(scope, element, attrs){
                var html = getTemplate(attrs.type)(attrs.key, attrs.value);
                element.html(html);
                $compile(element.contents())(scope);
            };

            return {
                restrict: "E",
                link: linker
            };
        });
}(angular));