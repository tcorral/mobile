(function (angular) {
    var module = angular.module('app');
    module.controller('WidgetPropertiesController', ['$rootScope', '$scope', '$location', 'localStorageService', '$route', 'authenticationService', 'widgetsService', function ($rootScope, $scope, $location, localStorageService, $route, authenticationService, widgetsService) {
        $scope.fileTypes = [
            'text-input',
            'select-one'
        ];

        $scope.roles = [
            'admin',
            'manager',
            'user',
            'none'
        ];

        $scope.getViewHintFixed = function (prop) {
            var newViewHint = [];
            if(prop.viewHint){
                prop.viewHint.forEach(function (item) {
                    if($scope.fileTypes.indexOf(item) !== -1) {
                        newViewHint[0] = item;
                    }else if ($scope.roles.indexOf(item) !== -1){
                        newViewHint[2] = item;
                    }else {
                        newViewHint[1] = item;
                    }
                });
                prop.viewHint = newViewHint;
            }
        };


        $scope.toggle = function (prop){
            prop.opened = !prop.opened;
        };

        $scope.isAdmin = authenticationService.isAdmin();

        $scope.isEditable = function (prop) {
            return $scope.isAdmin && prop.readonly === false && prop.manageable === true;
        };

        $scope.getField = function (key, value) {
            if( typeof controlTypes[key] === 'function') {
                return controlTypes[key](value);
            }else{
                return 'pepe';
            }
        };

        $scope.remove = function (prop){
            console.log(prop);
            var indexProp = $scope.properties.indexOf(prop);
            console.log(indexProp);
            $scope.widget.props.splice(indexProp, 1);
            //widgetsService
            //    .removeProperty(prop);
        };

        $scope.widget = JSON.parse(localStorageService.get('widget'));
        $scope.properties = $scope.widget.props;

        $scope.getLabel = function (prop) {
            return prop.label || _.startCase(prop.name);
        };

        $scope.getType = function (value) {
            return typeof value;
        };


        $scope.saveProperties = function (){
            var params = $route.current.params;
            var portal = params.portal;
            var properties = $scope.properties.slice(0);
            properties = properties.filter(function (item) {
               return !item.opened;
            });
            widgetsService
                .saveProperties(portal, $scope.widget.name, properties)
                .then(function (data){
                    console.log(data);
                    localStorageService.set('widget', JSON.stringify($scope.widget));
                });
        };

    }]);
}(angular));
