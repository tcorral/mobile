/**
 * portals data example
 * [
 *   {
 *     name: 'my portal',
 *     thumb: 'path/to/thumb.jpg'
 *   }
 * ]
 */
(function (angular) {
    var module = angular.module('app');
    module.controller('PortalsController', ['$rootScope', '$scope', '$location', 'portalsService', 'blockUI', function ($rootScope, $scope, $location, portalsService, blockUI) {

        $scope.portals = [];
        $scope.selectedPortals = [];

        $scope.getPortals = function (){
            blockUI.start();
            portalsService
                .getAll()
                .then(function (data) {
                    $scope.$evalAsync(function (){
                        $scope.portals = data;
                        $rootScope.filterSearch = '';
                    });
                })
                .finally(function(){
                    blockUI.stop();
                });
            $scope.selectedPortals = [];
        };

        $scope.getName = function (portal){
            return portal.props.filter(function (item, index) {
                return item.name === 'title';
            })[0].val;
        };

        $scope.getThumbnail = function (portal) {
            return portal.props.filter(function (item, index) {
                return item.name === 'thumbnailUrl';
            })[0].val;
        };

        $scope.openPortal = function (portal) {
            $scope.selectedPortals = [portal];
            $location.path('/portal/' + portal.name);
            $rootScope.$broadcast('selectedItems', {items: []})
        };

        $scope.toggleSelectedPortal = function (portal) {
            var indexOfPortalInSelectedPortals = $scope.selectedPortals.indexOf(portal);
            if(indexOfPortalInSelectedPortals === -1){
                $scope.selectedPortals.push(portal);
            }else {
                $scope.selectedPortals.splice(indexOfPortalInSelectedPortals, 1);
            }
            $rootScope.$broadcast('selectedItems', {items: $scope.selectedPortals})
        };

        $scope.isSelected = function (portal) {
            return $scope.selectedPortals.indexOf(portal) !== -1;
        };

        $scope.getPortals();
    }]);
}(angular));
