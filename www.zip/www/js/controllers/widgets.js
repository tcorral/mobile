(function (angular) {
    var module = angular.module('app');
    module.controller('WidgetsController', ['$rootScope', '$scope', '$location', '$route', 'widgetsService', 'localStorageService', 'blockUI', function ($rootScope, $scope, $location, $route, widgetsService, localStorageService, blockUI) {
        $scope.widgets = [];
        $scope.selectedWidgets = [];

        $scope.getWidgets = function () {
            blockUI.start();
            var params = $route.current.params;
            var portal = params.portal;
            var page = params.page;
            widgetsService
                .getAll(portal, page)
                .then(function (data) {
                    $scope.$evalAsync(function (){
                        $scope.widgets = data;
                    });
                })
                .finally(function(){
                    blockUI.stop();
                    $rootScope.filterSearch = '';
                });
            $scope.selectedWidgets = [];
        };

        $scope.getName = function (widget){
            return widget.props.filter(function (item, index) {
                return item.name === 'title';
            })[0].val;
        };

        $scope.getThumbnail = function (widget) {
            var thumbnail = widget.props.filter(function (item, index) {
                return item.name === 'thumbnailUrl';
            })[0];

            if(thumbnail) {
                return 'http://hackathon.backbase.dev:8080' + thumbnail.val;
            }
            return 'http://lorempixel.com/150/100';
        };

        $scope.openWidget = function (widget) {
            var params = $route.current.params;
            var portal = params.portal;
            var page = params.page;
            $scope.selectedWidgets = [widget];
            localStorageService.set('widget', JSON.stringify(widget));
            $location.path('/portal/' + portal + '/page/' + page + '/widget/' + widget.name);
            $rootScope.$broadcast('selectedItems', {items: []})
        };

        $scope.toggleSelectedWidget = function (widget) {
            var indexOfWidgetInSelectedWidgets = $scope.selectedWidgets.indexOf(widget);
            if(indexOfWidgetInSelectedWidgets === -1){
                $scope.selectedWidgets.push(widget);
            }else {
                $scope.selectedWidgets.splice(indexOfWidgetInSelectedWidgets, 1);
            }
            $rootScope.$broadcast('selectedItems', {items: $scope.selectedWidgets})
        };

        $scope.isSelected = function (widget) {
            return $scope.selectedWidgets.indexOf(widget) !== -1;
        };

        $scope.getWidgets();
    }]);
}(angular));
