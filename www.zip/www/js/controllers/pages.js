/**
 * pages data example
 * [
 *   {
 *     name: 'mp1',
 *     thumb: 'path/to/thumb.jpg',
 *     extendedPages: [
 *          {
 *              name: 'p1',
 *              thumb: 'path/to/thumb1.jpg'
 *          }
 *     ]
 *   }
 * ]
 */
(function (angular) {
    var module = angular.module('app');
    module.controller('PagesController', ['$rootScope', '$scope', '$location', '$timeout', '$route', 'pagesService', 'colorsService', 'blockUI', function ($rootScope, $scope, $location, $timeout, $route, pagesService, colorsService, blockUI) {
        $scope.pages = [];
        $scope.selectedPages = [];
        $scope.masterpageThumb = 'http://lorempixel.com/150/100?';
        $scope.pageThumb = 'http://lorempixel.com/150/100';
        $scope.lastMasterPage = null;

        $scope.color = colorsService.getColor;

        $scope.setStyle = function () {
            var color = colorsService.getColor();
            console.log(color);
            //$scope.$evalAsync(function () {
                //$scope.myStyle = { padding:  '4px', backgroundColor: color };
                return { padding:  '4px', backgroundColor: color };
            //});

        };

        $scope.getPages = function () {
            blockUI.start();
            var params = $route.current.params;
            var portal = params.portal;
            pagesService
                .getAll(portal)
                .then(function (data) {
                    $scope.$evalAsync(function (){
                        $scope.pages = data;
                        $rootScope.title = portal;
                        $rootScope.filterSearch = '';
                    });
                })
                .finally(function(){
                    blockUI.stop();
                });
            $scope.selectedPages = [];
        };

        $rootScope.$broadcast('selectedItems', {items: []});

        $scope.openPage = function (page) {
            var params = $route.current.params;
            var portal = params.portal;
            $scope.selectedPages = [page];
            $location.path('/portal/' + portal + '/page/' + page.name);
            $rootScope.$broadcast('selectedItems', {items: []})
        };

        $scope.toggleSelectedPage = function (page) {
            var indexOfPageInSelectedPages = $scope.selectedPages.indexOf(page);
            if(indexOfPageInSelectedPages === -1){
                $scope.selectedPages.push(page);
            } else {
                $scope.selectedPages.splice(indexOfPageInSelectedPages, 1);
            }
            $rootScope.$broadcast('selectedItems', {items: $scope.selectedPages})
        };

        $rootScope.$on('delete:selected:pages', function () {
            var page = $scope.selectedPages.shift();
            while(page){
                var posMasterPage = $scope.pages.indexOf(page);
                if(posMasterPage !== -1) {
                    $scope.pages.splice(posMasterPage, 1);
                }
                page = $scope.selectedPages.shift();
            }
        });
        //$rootScope.$on('get:selected:pages', function () {
        //    $rootScope.$broadcast('return:selected:pages', { data: $scope.selectedPages });
        //});

        $scope.getName = function (page){
            return page.props.filter(function (item, index) {
                return item.name === 'title';
            })[0].val;
        };

        $scope.getThumbnail = function (page) {
            var thumbnailUrl = page.props.filter(function (item, index) {
                return item.name === 'thumbnailUrl';
            })[0];
            if(thumbnailUrl){
                return 'http://hackathon.backbase.dev:8080' + thumbnailUrl.val;
            }
            return $scope.pageThumb;
        };

        $scope.isSelected = function (page) {
            return $scope.selectedPages.indexOf(page) !== -1
        };

        $scope.getPages();
    }]);
}(angular));
