/**
 * pages data example
 * [
 *   {
 *     name: 'mp1',
 *     thumb: 'path/to/thumb.jpg',
 *     extendedPages: [
 *          {
 *              name: 'p1',
 *              thumb: 'path/to/thumb1.jpg'
 *          }
 *     ]
 *   }
 * ]
 */
(function (angular) {
    var module = angular.module('app');
    module.controller('PagesController', ['$rootScope', '$scope', '$location', '$timeout', '$route', 'pagesService', 'colorsService', 'blockUI', function ($rootScope, $scope, $location, $timeout, $route, pagesService, colorsService, blockUI) {
        $scope.pages = [];
        $scope._pages = [];
        $scope.selectedPages = [];
        $scope.masterpageThumb = 'http://lorempixel.com/150/100?';
        $scope.pageThumb = 'http://lorempixel.com/150/100';
        $scope.lastMasterPage = null;

        var myStyle = {};

        $scope.setStyle = function (masterPage) {
            if($scope.lastMasterPage !== masterPage){
                myStyle = { padding: '2px', backgroundColor: colorsService.getColor()};
                $scope.lastMasterPage = masterPage;
            }
            return myStyle;
        };

        $scope.getPages = function () {
            blockUI.start();
            var params = $route.current.params;
            var portal = params.portal;
            pagesService
                .getAll(portal)
                .then(function (data) {
                    $scope.$evalAsync(function (){
                        $scope.pages = data;
                        $rootScope.title = portal;
                        $rootScope.filterSearch = '';
                    });
                })
                .finally(function(){
                    blockUI.stop();
                });
            $scope.selectedPages = [];
        };

        $rootScope.$broadcast('selectedItems', {items: []});

        $scope.openPage = function (page) {
            var params = $route.current.params;
            var portal = params.portal;
            $scope.selectedPages = [page];
            $location.path('/portal/' + portal + '/page/' + page.name);
            $rootScope.$broadcast('selectedItems', {items: []})
        };

        $scope.toggleSelectedPage = function (page) {
            var indexOfPageInSelectedPages = $scope.selectedPages.indexOf(page);
            if(indexOfPageInSelectedPages === -1){
                $scope.selectedPages.push(page);
            } else {
                $scope.selectedPages.splice(indexOfPageInSelectedPages, 1);
            }
            $rootScope.$broadcast('selectedItems', {items: $scope.selectedPages})
        };

        $scope.getName = function (page){
            return page.props.filter(function (item, index) {
                return item.name === 'title';
            })[0].val;
        };

        $scope.getThumbnail = function (page) {
            var thumbnailUrl = page.props.filter(function (item, index) {
                return item.name === 'thumbnailUrl';
            })[0];
            if(thumbnailUrl){
                return 'http://hackathon.backbase.dev:8080' + thumbnailUrl.val;
            }
            return $scope.pageThumb;
        };

        $scope.isSelected = function (page) {
            return $scope.selectedPages.indexOf(page) !== -1
        };

        $scope.getPages();
    }]);
}(angular));
