(function (JXON, ns, angular) {
    'use strict';

    JXON.config({
        valueKey: '_',        // default: 'keyValue'
        attrKey: '$',         // default: 'keyAttributes'
        attrPrefix: '$',      // default: '@'
        lowerCaseTags: false, // default: true
        trueIsEmpty: false,   // default: true
        autoDate: false,      // default: true
        ignorePrefixedNodes: false // default: true
    });

    var bbrest = new BBRest({
        host: 'hackathon.backbase.dev',
        port: '8080',
        context: 'portalserver',
        username: 'admin',
        password: 'admin',
        portal: null, // name of the targeted portal,
        plugin: jxonr
    });

    function jxonr(d) {
        if (typeof d === 'string') return JXON.stringToJs(d);
        else return JXON.jsToString(d);
    }
    function parseProps(o) {
        var ret = [];
        _.each(o.property, function(prop) {
            var val = prop.value._;
            if (typeof val === 'undefined') return true;
            var r = {
                val: ((typeof val === 'string') ? resolvePaths(val) : val)
            };
            _.each(prop, function(v, k) {
                if (k !== 'value') {
                    r[k.substr(1)] = (k === '$viewHint') ? v.split(',') : v;
                }
            });
            ret.push(r);
        });
        ret = ret.sort(function(a, b) {
            return a.name.toUpperCase().localeCompare(b.name.toUpperCase());
        });
        return ret;
    }
    function propsToJx(props) {
        var ret = [], o;
        _.each(props, function(v, k) {
            o = {};
            for (var i in v) {
                if (i === 'viewHint') {
                    o['$' + i] = v[i].reverse().join(',');
                } else if (i === 'val') {
                    o.value = {
                        $type: (i === 'order') ? 'float' : typeof v[i],
                        _: v[i]
                    }
                } else {
                    o['$' + i] = v[i];
                }
            }
            ret.push(o);
        });
        return {property: ret};
    }
    function resolvePaths(string) {
        return string.replace(/(\$\(contextRoot\))|(\$\(servicesPath\))/, '/portalserver');
    }
    function reorderPages(o) {
        var masters = [];
        _.each(o, function(v, k) {
            if (!v.extends) {
                var vc = _.cloneDeep(v);
                masters.push(vc);
                delete vc.extends;
            };
        });
        _.each(o, function(v, k) {
            if (!v.extends) return true;
            var m = _.where(masters, {name: v.extends})[0];
            if (!m.extended) m.extended = [];
            m.extended.push(v);
        });
        return masters;
    }
    function findChildren(col, parent, a) {
        a = a || [];
        _.each(_.where(col, {parentItemName: parent}), function(v) {
            a.push(v);
            return findChildren(col, v.name, a);
        });
        return a;
    }

    var pageCache;

    ns.CXP = {
        getPortals: function() {
            return bbrest.server().get().then(function(data) {
                var r = [];
                var portals = data.body.portals.portal;
                _.each(portals, function(portal) {
                    var props = parseProps(portal.properties);
                    r.push({
                        name: portal.name,
                        title: _.startCase(_.where(props, {name: 'title'})[0].val),
                        props: props
                    });
                });
                r = _.sortBy(r, 'title');
                return r;
            });
        },
        getPages: function(portalName) {
            bbrest.config.portal = portalName;
            return bbrest.page().get().then(function(data) {
                pageCache = [];
                var pages = data.body.pages.page;
                _.each(pages, function(page) {
                    var props = parseProps(page.properties);
                    pageCache.push({
                        name: page.name,
                        title: _.startCase(_.where(props, {name: 'title'})[0].val),
                        extends: page.extendedItemName,
                        props: props
                    });
                });
                var r = reorderPages(pageCache);
                r = _.sortBy(r, 'title');
                return r;
            });
        },
        getWidgets: function(portalName, pageName) {
            bbrest.config.portal = portalName;
            return bbrest.container().query({ps: -1, pc: false}).get().then(function(data) {
                var containers = data.body.containers.container;
                var r = [];
                var c = findChildren(containers, pageName);
                _.each(c, function(v) {
                    var w = v.children.widget;
                    if (w) {
                        if (!w.length) w = [w];
                        _.each(w, function(wv) {
                            var props = parseProps(wv.properties);
                            r.push({
                                name: wv.name,
                                title: _.startCase(_.where(props, {name: 'title'})[0].val),
                                extends: wv.extendedItemName,
                                props: props
                            });
                        });
                    }
                });

                r = _.sortBy(r, 'title');
                return r;
            });
        },
        config: function(props) {
            if (props) {
                bbrest.config = _.extend(bbrest.config, props);
                return bbrest.config;
            } else {
                return bbrest.config;
            }
        },
        updateProps: function(portalName, type, name, props) {
            bbrest.config.portal = portalName;
            var jx = {};
            jx[type + 's'] = {};
            jx[type + 's'][type] = {
                name: name,
                properties: propsToJx(props)
            };
            return bbrest[type]().put(jx)
            .then(function(r) {
                console.log(r);
            });
        }
    };

// ns.CXP.getPages('retail-banking')
// .then(function(d) {
// });
// home         page_1415023295044
// springboard  page_1415103508210
// dashboard    page_1415023267479
// launcher     page_1415023255184


// ns.CXP.getPages('retail-banking')
// .then(function(d) {
//     var page = d[0].extended[0];
//     _.where(page.props, {name: 'title'})[0].val = 'test9';
//     console.log(page.props);
//
//     ns.CXP.updateProps('page', page.name, page.props);
//     //console.log(d);
// });

}(JXON, window, angular));
