(function (angular, ns) {

    angular
        .module('app', ['ngRoute', 'angular-gestures', 'LocalStorageModule', 'blockUI', 'ngDialog'])
        .config(['$locationProvider', '$routeProvider', 'hammerDefaultOptsProvider', 'localStorageServiceProvider', 'blockUIConfig',
            function ($locationProvider, $routeProvider, hammerDefaultOptsProvider, localStorageServiceProvider, blockUIConfig) {
                $locationProvider.html5Mode(false);

                blockUIConfig.template = '<div class="block-ui-overlay"></div><div class="block-ui-message-container" aria-live="assertive" aria-atomic="true"> <div class="block-ui-message" ng-class="$_blockUiMessageClass"><img src="../img/spinner.gif" width="50" /></div></div>';

                localStorageServiceProvider
                    .setPrefix('dora')
                    .setStorageType('localStorage');

                $routeProvider.
                    when('/portals', {
                        templateUrl: 'templates/portals.html',
                        controller: 'PortalsController'
                    }).
                    when('/portal/:portal', {
                        templateUrl: 'templates/pages.html',
                        controller: 'PagesController'
                    }).
                    when('/portal/:portal/page/:page', {
                        templateUrl: 'templates/widgets.html',
                        controller: 'WidgetsController'
                    }).
                    when('/portal/:portal/page/:page/widget/:widget', {
                        templateUrl: 'templates/widget_properties.html',
                        controller: 'WidgetPropertiesController'
                    }).
                    otherwise({
                        redirectTo: '/portals'
                    });
                hammerDefaultOptsProvider.set({
                    recognizers: [
                        [Hammer.Tap, {time: 250, enable: true}],
                        [Hammer.Press, {enable: true}]
                    ]
                });
            }
        ])
        .factory('portalsService', function () {
            return {
                getAll: function () {
                    return ns.CXP.getPortals();
                }
            };
        })
        .factory('pagesService', function () {
            return {
                getAll: function (portalName) {
                    return ns.CXP.getPages(portalName);
                },
                remove: function (pages){

                }
            };
        })
        .factory('authenticationService', function () {
            return {
                isAdmin: function () {
                    return ns.CXP.config()
                        .username === 'admin';
                }
            };
        })
        .factory('colorsService', function () {
            return {
                getColor: function () {
                    return "rgb(" + (Math.random() * 256 | 0) + ", " + (Math.random() * 256 | 0) + ", " + (Math.random() * 256 | 0) + ")";
                }
            };
        })
        .factory('widgetsService', function () {
            return {
                getAll: function (portalName, pageName) {
                    return ns.CXP.getWidgets(portalName, pageName);
                },
                removeProperty: function (){

                },
                saveProperties: function (portalName, name, properties) {
                    return ns.CXP.updateProps(portalName, 'widget', name, properties);
                }
            };
        })
        .run(function($rootScope){
            $rootScope.filterSearch = '';

            $rootScope.title = 'CXP Dora Explorer';
            $rootScope.$on( "$routeChangeStart", function(event, next, current) {
                if(next.$$route.controller !== 'PortalsController'){
                    $rootScope.backButton = true;
                }else{
                    $rootScope.backButton = false;
                }
            });
        })
}(angular, window));
